<?php

namespace App\Utils;

class DeleveryState
{

    public CONST REJECTED = -1;
    public CONST WAIT_DELIVERY = 0;
    public CONST DELIVERED = 1;
    public CONST NOT_DELIVERED = 2;

}
