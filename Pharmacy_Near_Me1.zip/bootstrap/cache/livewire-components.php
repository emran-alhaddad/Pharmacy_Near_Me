<?php return array (
  'message' => 'App\\Http\\Livewire\\Message',
  'show' => 'App\\Http\\Livewire\\Show',
);