                      <div class="tab-pane fade show active" id="navs-top-accept" role="tabpanel">
                        <div class="card">
                            <h5 class="card-header"> الطلبات</h5>
                            <div class="table-responsive text-nowrap">
                                <table class="table table-hover">
                                    <thead>
                                        <tr>
                                            <th>الرقم</th>
                                            <th>اسم العميل</th>
                                            <th>تاريخ الطلبية </th>
                                            <th>حالة الطلبية </th>
                                            <th>سعر الطلبية </th>
                                            <!-- <th>العمليات</th> -->
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr>
                                            <td><i class="fab fa-angular fa-lg text-danger me-3"></i> <strong>1</strong></td>
                                            <td><i class="fab fa-angular fa-lg text-danger me-3"></i> <strong>وفاء الصبري  </strong></td>
                                            <td><i class="fab fa-angular fa-lg text-danger me-3"></i> <strong>2022-5-3</strong></td>
                                            <td><span class="badge bg-label-secondary me-1">في انتظار القبول</span></td>
                                            <td><i class="fab fa-angular fa-lg text-danger me-3"></i> <strong>100</strong></td>
                                            <td> <a  class="demo-inline-spacing" href="#collapseExample"
                                            data-bs-toggle="collapse"
                                            role="button"
                                            aria-expanded="false"
                                            aria-controls="collapseExample"> تفاصيل الطلبية</a></td>
                                            <td>
                                        
                                            </td>
                                        </tr>
                                        <tr>
                                            <td><i class="fab fa-angular fa-lg text-danger me-3"></i> <strong>2</strong></td>
                                            <td><i class="fab fa-angular fa-lg text-danger me-3"></i> <strong>حنين الحبشي  </strong></td>
                                            <td><i class="fab fa-angular fa-lg text-danger me-3"></i> <strong>2022-5-3</strong></td>
                                            <td><span class="badge bg-label-secondary me-1">في انتظار القبول</span></td>
                                            <td><i class="fab fa-angular fa-lg text-danger me-3"></i> <strong>100</strong></td>
                                            <td> <a  class="demo-inline-spacing" href="#collapseExample"
                                            data-bs-toggle="collapse"
                                            role="button"
                                            aria-expanded="false"
                                            aria-controls="collapseExample"> تفاصيل الطلب</a></td>
                                            <td>
                                        
                                            </td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                      </div>