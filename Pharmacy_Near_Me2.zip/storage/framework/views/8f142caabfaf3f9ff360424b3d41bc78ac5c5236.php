<div id="done" class="tab-pane fade">
    <table class="table table-striped">
        <thead>
            <tr>
                <th scope="col">رقم الطلبية</th>
                <th scope="col">الصيدلية</th>
                <th scope="col">تاريخ الطلبية</th>
                <th scope="col">سعر الطلبية</th>
                <th scope="col">حالة الطلبية</th>
                <th scope="col">العمليات</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $requests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $request): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($request->state == \App\Utils\RequestState::FINISHED): ?>
                    <tr>
                        <th scope="row"><?php echo e($loop->iteration); ?></th>
                        <td><?php echo e($request->pharmacy->user->name); ?></td>
                        <td><?php echo e($request->created_at->diffForHumans()); ?></td>
                        <td>
                            <?php echo e($request->replies->details->sum('drug_price')); ?>

                        </td>
                        <td><span class="badge bg-warning text-dark" style="background-color:green;">مكتملة</span></td>
                        <td><a class="btn btn-submit btn-hover text-light me-2" data-bs-toggle="collapse" role="button"
                                data-bs-target="#details<?php echo e($request->id); ?>" aria-expanded="false"
                                aria-controls="collapseExample">
                                عرض التفاصيل
                            </a></td>
                    </tr>

                    <tr>
                        <td colspan="6">
                            <div class=" collapse" id="details<?php echo e($request->id); ?>">
                                <div class="card card-body">
                                    <table class="table">
                                        <thead>
                                            <tr>
                                                <th scope="col">أسم/صورة العلاج</th>
                                                <th scope="col"> الكمية</th>
                                                <th scope="col">أقبل البدائل</th>
                                                <th scope="col">العمليات </th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php $__currentLoopData = $request->details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $requestDetails): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php $__currentLoopData = $request->replies->details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rep_det): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <?php if($requestDetails->id == $rep_det->request_details_id && $rep_det->state == \App\Utils\ReplyState::ACCEPTED): ?>
                                                        <tr>
                                                            <td>
                                                                <?php if($requestDetails->drug_image): ?>
                                                                    <li data-bs-toggle="tooltip"
                                                                        data-popup="tooltip-custom"
                                                                        data-bs-placement="top" class="avatar pull-up"
                                                                        title="صورة العلاج "
                                                                        style="list-style-type: none;">
                                                                        <img src="<?php echo e(asset('uploads/requests/' . $requestDetails->drug_image)); ?>"
                                                                            alt="Avatar" class="rounded-circle image_show">
                                                                    </li>
                                                                <?php endif; ?>
                                                                <strong><?php echo e($requestDetails->drug_title); ?></strong>
                                                            </td>
                                                            <td><?php echo e($requestDetails->quantity); ?></td>
                                                            <td>
                                                                <?php if($requestDetails->accept_alternative): ?>
                                                                    <span class="badge bg-success text-light">
                                                                        نعم
                                                                    <?php else: ?>
                                                                        <span class="badge bg-danger text-light">
                                                                            لا
                                                                <?php endif; ?>
                                                                </span>
                                                            </td>
                                                            <td><a class="btn btn-primary" data-toggle="collapse"
                                                                    href="#reply<?php echo e($requestDetails->id); ?>"
                                                                    role="button" aria-expanded="false"
                                                                    aria-controls="collapseExample">
                                                                    عرض الرد
                                                                </a>
                                                            </td>
                                                        </tr>

                                                        <tr>
                                                            <td colspan="5">
                                                                <div class=" collapse"
                                                                    id="reply<?php echo e($requestDetails->id); ?>">
                                                                    <div class="card card-body">
                                                                        <table class="table">
                                                                            <thead>
                                                                                <tr>
                                                                                    <th scope="col">أسم/صورة العلاج</th>
                                                                                    <th scope="col"> الكمية</th>
                                                                                    <th scope="col">نوع الرد</th>
                                                                                    <th scope="col">سعر العلاج </th>
                                                                                    <th scope="col">قبول الرد </th>
                                                                                </tr>
                                                                            </thead>
                                                                            <tbody>
                                                                                <?php $__currentLoopData = $request->replies->details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $replyDetails): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                                    <?php if($requestDetails->id == $replyDetails->request_details_id): ?>
                                                                                        <tr>
                                                                                            <?php if($replyDetails->drug_price): ?>
                                                                                                <td>
                                                                                                    <?php if($requestDetails->drug_image): ?>
                                                                                                        <li data-bs-toggle="tooltip"
                                                                                                            data-popup="tooltip-custom"
                                                                                                            data-bs-placement="top"
                                                                                                            class="avatar pull-up"
                                                                                                            title="صورة العلاج "
                                                                                                            style="list-style-type: none;">
                                                                                                            <img src="<?php echo e(asset('uploads/requests/' . $requestDetails->drug_image)); ?>"
                                                                                                                alt="Avatar"
                                                                                                                class="rounded-circle image_show">
                                                                                                        </li>
                                                                                                    <?php endif; ?>
                                                                                                    <strong><?php echo e($requestDetails->drug_title); ?></strong>
                                                                                                </td>
                                                                                                <td><?php echo e($requestDetails->quantity); ?>

                                                                                                </td>
                                                                                                <td><span
                                                                                                        class="badge bg-primary text-light">اساسي</span>
                                                                                                </td>
                                                                                                <td><?php echo e($replyDetails->drug_price); ?>

                                                                                                </td>
                                                                                            <?php else: ?>
                                                                                                <td>
                                                                                                    <?php if($replyDetails->alt_drug_image): ?>
                                                                                                        <li data-bs-toggle="tooltip"
                                                                                                            data-popup="tooltip-custom"
                                                                                                            data-bs-placement="top"
                                                                                                            class="avatar pull-up"
                                                                                                            title="صورة العلاج "
                                                                                                            style="list-style-type: none;">
                                                                                                            <img src="<?php echo e(asset('uploads/replies/' . $replyDetails->alt_drug_image)); ?>"
                                                                                                                alt="Avatar"
                                                                                                                class="rounded-circle image_show">
                                                                                                        </li>
                                                                                                    <?php endif; ?>
                                                                                                    <strong><?php echo e($replyDetails->alt_drug_title); ?></strong>
                                                                                                </td>

                                                                                                <td><?php echo e($requestDetails->quantity); ?>

                                                                                                </td>
                                                                                                <td><span
                                                                                                        class="badge bg-secondary text-light">بديل</span>
                                                                                                </td>
                                                                                                <td><?php echo e($replyDetails->alt_drug_price); ?>

                                                                                                </td>
                                                                                            <?php endif; ?>


                                                                                            <td>
                                                                                                <span
                                                                                                    class="badge bg-success text-light">تم
                                                                                                    قبول الرد</span>
                                                                                            </td>
                                                                                        </tr>
                                                                                    <?php endif; ?>
                                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                            </tbody>
                                                                        </table>
                                                                    </div>
                                                                </div>
                                                            </td>
                                                        </tr>
                                                    <?php endif; ?>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </td>
                    </tr>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<?php /**PATH C:\Users\Dell\Desktop\PROJECT صيدليتي\Pharmacy_Near_Me\resources\views/user/state/completed.blade.php ENDPATH**/ ?>