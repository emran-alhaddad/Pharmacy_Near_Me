

<?php $__env->startSection('content'); ?>

    
    <section id="pay" class="contact-us section  radius search-area" style="direction: rtl; z-index: 00000000;">
        <div class="container">
            <div class="contact-head wow fadeInUp" data-wow-delay=".4s">
                <form
                    <?php if(!isset($request['is_advertising'])): ?> action="<?php echo e(route('user-payment-pay', $request['order_reference'])); ?>"
                <?php else: ?>  action="<?php echo e(route('user-payment-ads-pay', $request['order_reference'])); ?>" <?php endif; ?>
                    method="post" class="row p-2  shadow radius">

                    <div class="text-center banner-area ">
                        <h3 class="heading text-white">عملية الدفع</h3>
                    </div>

                    <div class="col-lg-6 col-12 radius p-5 ">
                        <div class="form-main">
                            <div class="text-center">
                                <h3 class="heading" style="font-size: 1.6rem">المعلومات <span>الشخصية </span></h3>
                            </div>
                            <div class="form">
                                <div class="row">
                                    <?php echo csrf_field(); ?>
                                    <div class="p-4">

                                        <div class="input-group mb-3">
                                            <span class="input-group-text rounded"
                                                style="background-color: var(--main-color)"><i
                                                    class="bi bi-person-fill text-white"></i></span>
                                            <input
                                                <?php if(isset($request['is_advertising'])): ?> value="<?php echo e($request['ads_owner']->name); ?>"
                                                   <?php else: ?> value="<?php echo e(Auth::user()->name); ?>" <?php endif; ?>
                                                type="text" placeholder="اسم المستخدم" name="name"
                                                class="form-control rounded <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-danger <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                            <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="invalid-feedback d-block">
                                                    <?php echo e($message); ?>

                                                </div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>

                                        <div class="input-group mb-3">
                                            <span class="input-group-text rounded"
                                                style="background-color: var(--main-color)"><i
                                                    class="bi bi-envelope-fill text-white"></i></span>
                                            <input type="email"
                                                <?php if(isset($request['is_advertising'])): ?> value="<?php echo e($request['ads_owner']->email); ?>"
                                                   <?php else: ?> value="<?php echo e(Auth::user()->email); ?>" <?php endif; ?>
                                                placeholder="example@example.com" name="email"
                                                class="form-control rounded <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-danger <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="invalid-feedback d-block">
                                                    <?php echo e($message); ?>

                                                </div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                        <?php if(!isset($request['is_advertising'])): ?>
                                            <div class="input-group mb-3">
                                                <span class="input-group-text rounded"
                                                    style="background-color: var(--main-color)"><i
                                                        class="lni lni-map-marke text-white"></i></span>
                                                <input type="address" value="" placeholder="وصف العنوان " name="address"
                                                    class="form-control rounded <?php $__errorArgs = ['address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-danger <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                                <?php $__errorArgs = ['address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <div class="invalid-feedback d-block">
                                                        <?php echo e($message); ?>

                                                    </div>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>

                                            <div class="input-group mb-3 rounded">
                                                <div class="dropdown col-12">
                                                    <select name="city" id="location" class="col-12 rounded form-control">
                                                        <option value="none" selected disabled> المدينة </option>
                                                        <?php $__currentLoopData = $cities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <option value="<?php echo e($city->id); ?>"><?php echo e($city->name); ?>

                                                            </option>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </select>
                                                </div>
                                            </div>

                                            <div class="input-group mb-3 rounded">
                                                <div class="dropdown col-12">
                                                    <select name="zone" id="category" class="col-12 rounded form-control">
                                                        <option value="none" selected disabled> الحي </option>
                                                        <?php $__currentLoopData = $zones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $zone): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <option value="<?php echo e($zone->id); ?>"><?php echo e($zone->name); ?>

                                                            </option>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </select>
                                                </div>
                                            </div>
                                        <?php else: ?>
                                            <input type="hidden" name="is_advertising" value="true" />
                                        <?php endif; ?>

                                    </div>
                                </div>
                            </div>

                        </div>
                    </div>

                    <div class="col-lg-6 col-12 radius p-5 ">
                        <div class="form-main">
                            <div class="text-center">
                                <h3 class="heading" style="font-size: 1.6rem">تفاصيل <span>الطلبية</span></h3>
                            </div>
                            <div class="form">
                                <div class="row">

                                    <div class="row">
                                        <div>
                                            <hr>
                                            <div class="d-flex justify-content-between align-items-center mb-4">
                                                <div>
                                                    <p class="mb-0"> لديك
                                                        <?php echo e($request['total_products']); ?>

                                                        منتجات في انتظار الدفع </p>
                                                </div>
                                            </div>

                                            <?php $__currentLoopData = $request['products']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <div class="card mb-3 col-12">
                                                    <div class="card-body">
                                                        <div class="d-flex justify-content-between">
                                                            <?php if($product['drug_price']): ?>
                                                                <div class="d-flex flex-row align-items-center">
                                                                    <?php if(isset($product['drug_image'])): ?>
                                                                        <div>

                                                                            <img src="<?php echo e(asset('uploads/' . $product['drug_image'])); ?>"
                                                                                class="img-fluid rounded-pill border border-dark p-2"
                                                                                alt="Shopping item"
                                                                                style="width: 65px; cursor:pointer;">
                                                                        </div>
                                                                    <?php endif; ?>
                                                                    <?php if(isset($product['drug_title'])): ?>
                                                                        <div class="ms-3">
                                                                            <h5><?php echo e($product['drug_title']); ?> </h5>
                                                                        </div>
                                                                    <?php endif; ?>
                                                                </div>
                                                                <div class="d-flex flex-row align-items-center">
                                                                    <div style="width: 50px;">
                                                                        <h5 class="fw-normal mb-0">
                                                                            <?php echo e($product['quantity']); ?></h5>
                                                                    </div>
                                                                    <div style="width: 80px;">
                                                                        <h5 class="mb-0">
                                                                            $<?php echo e($product['drug_price']); ?></h5>
                                                                    </div>
                                                                </div>
                                                            <?php endif; ?>
                                                        </div>
                                                    </div>
                                                </div>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                                            <hr>
                                            <div class="d-flex justify-content-around mb-5">
                                                <h5 class="text-uppercase">اجمالي السعر </h5>
                                                <h5>$<?php echo e($request['total_price']); ?></h5>
                                            </div>
                                        </div>
                                        <?php if($request['total_price'] <= 0): ?>
                                            <div class="alert alert-danger alert-dismissible" role="alert">
                                                عزيزنا العميل ... يجب عليك أولا قبول رد واحد من ردود الصيدلية على الأقل لكي
                                                تتمكن من اتمام عملية الدفع
                                                <button type="button" class="btn-close" data-bs-dismiss="alert"
                                                    aria-label="Close"></button>
                                            </div>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="col-12 d-flex justify-content-center p-1 my-2 radius">
                        <div class="form-group d-flex justify-content-center col-6">
                            <?php if($request['total_price'] <= 0): ?>
                                <a href="<?php echo e(url()->previous()); ?>" class="main-btn col-6 btn-hover">
                                    عودة للصفحة السابقة
                                </a>
                            <?php else: ?>
                                <button type="submit" class="main-btn col-6 btn-hover">دفع </button>
                            <?php endif; ?>

                        </div>
                    </div>
                </form>
            </div>
        </div>
    </section>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.masterFront', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Dell\Desktop\PROJECT صيدليتي\Pharmacy_Near_Me\resources\views/payment/payment.blade.php ENDPATH**/ ?>