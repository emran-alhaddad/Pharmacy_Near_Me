
<script src="http://html2canvas.hertzen.com/dist/html2canvas.min.js"></script>
<?php $__env->startSection('content'); ?>

    

    <section id="pay" class=" section radius" style="direction: rtl; margin: 120px 0px; z-index: 0; ">
        <div class="container mt-5">
            <div class="contact-head wow fadeInUp " data-wow-delay=".4s">
                <div class="row p-2  shadow radius mt-5">
                    <div class="card " id="bill">
                        <div class="card-header">
                            <p class="" style="font-size: 30px;">فاتورة دفع </p>
                            <button class="btn btn-primary" id="print_bill">
                            طباعة الفاتورة
                            </button>
                        </div>
                        <div class="card-body mx-4">
                            <div class="container" >

                                <div class="row">
                                    <ul class="list-unstyled d-flec flex-row">
                                        <li class="text-var(--main-color)"><?php echo e($client['name']); ?></li>
                                        <li class="text-muted mt-1"><span class="text-var(--main-color)">رقم الفاتورة</span>
                                            #<?php echo e($order_reference); ?></li>
                                        <li class="text-var(--main-color) mt-1"> <?php echo e($created_at); ?></li>
                                    </ul>
                                    <hr>
                                </div>
                                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="row">
                                        <div class="col-xl-8">
                                            <p><?php echo e($product['product_name']); ?></p>
                                        </div>
                                        <div class="col-xl-2">
                                            <p><?php echo e($product['quantity']); ?></p>
                                        </div>
                                        <div class="col-xl-2">
                                            <p class="float-end">$<?php echo e($product['unit_amount']); ?>

                                            </p>
                                        </div>
                                        <hr>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                                <div class="row text-var(--main-color)">

                                    <div class="col-xl-12">
                                        <p class="float-end fw-bold">الاجمالي : <?php echo e($paid_amount); ?>$
                                        </p>
                                    </div>
                                    <hr style="border: 2px solid var(--main-color);">
                                </div>

                                <div class="text-center p-4" role="button">
                                <a href="<?php echo e(route('index')); ?>" class="btn btn-outline-primary">إكمال التصفح </a>
                            </div>

                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </section>

<script src="https://cdnjs.cloudflare.com/ajax/libs/html2canvas/0.4.1/html2canvas.js"></script>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/1.0.272/jspdf.debug.js"></script>

    <script src="https://code.jquery.com/jquery-3.6.0.min.js" integrity="sha256-/xUj+3OJU5yExlq6GSYGSHk7tPXikynS7ogEvDej/m4=" crossorigin="anonymous"></script>
<script>

        $(document).on('click', '#print_bill', function () {

            let pdf = new jsPDF();
            let section = $('#bill');
            let page = function () {
                pdf.save('bill.pdf');
            };
            pdf.addHTML(section, page);
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.masterFront', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Dell\Desktop\PROJECT صيدليتي\Pharmacy_Near_Me - Copy\resources\views/payment/successPay.blade.php ENDPATH**/ ?>