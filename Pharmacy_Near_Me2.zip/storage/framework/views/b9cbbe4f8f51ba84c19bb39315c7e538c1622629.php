

<?php

if (!function_exists('isPhoto')) 
{
    function isPhoto($path) 
    {
        // Get the file extension from the path
        $exploded = explode('.', $path);
        $ext = strtolower(end($exploded));
        // Define the photos extensions
        $photoExtensions = ['png', 'jpg', 'jpeg', 'gif', 'jfif', 'tif', 'webp'];
        // Check if this extension belongs to the extensions we defined
        if (in_array($ext, $photoExtensions)) {
            return true;
        }
        return false;
    }
}

if (!function_exists('isVideo')) 
{
    function isVideo($path) 
    {
        // Get the file extension from the path
        $exploded = explode('.', $path);
        $ext = end($exploded);
        // Define the videos extensions
        $videoExtensions = ['mov', 'mp4', 'avi', 'wmf', 'flv', 'webm'];
        // Check if this extension belongs to the extensions we defined
        if (in_array($ext, $videoExtensions)) {
            return true;
        }
        return false;
    }
}
?>



<div>
    <div class="row justify-content-center m-5">
        <?php if(auth()->user()->is_active == true): ?>
            <div class="col-md-4">
                <div class="card">
                    <div class="card-header">
                        المستخدمين
                    </div>
                    <div class="card-body chatbox p-0">
                        <ul class="list-group list-group-flush">
                            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php
                                    $not_seen = \App\Models\Messages::where('user_id', $user->id)->where('receiver', auth()->id())->where('is_seen', false)->get() ?? null
                                ?>
                                <a href="<?php echo e(route('inbox.show', $user->id)); ?>" class="text-dark link">
                                    <li class="list-group-item" wire:click="getUser(<?php echo e($user->id); ?>)" id="user_<?php echo e($user->id); ?>">
                                        <img class="img-fluid avatar" src="http://127.0.0.1:8000/uploads/avaters/client/avater.png">
                                        <?php if($user->is_online): ?> <i class="fa fa-circle text-success online-icon"></i> <?php endif; ?> <?php echo e($user->name); ?>

                                        <?php if(filled($not_seen)): ?>
                                            <div class="badge badge-success rounded"><?php echo e($not_seen->count()); ?></div>
                                        <?php endif; ?>
                                    </li>
                                </a>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                </div>
            </div>
        <?php endif; ?>
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">
                    <?php echo e($sender->name); ?>

                </div>
                <div class="card-body message-box" wire:poll.10ms="mountComponent()">
                    <?php if(filled($messages)): ?>
                        <?php $__currentLoopData = $messages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="single-message <?php if($message->user_id !== auth()->id()): ?> received <?php else: ?> sent <?php endif; ?>">
                                <p class="font-weight-bolder my-0"><?php echo e($message->user->name); ?></p>
                                <p class="my-0"><?php echo e($message->message); ?></p>
                                <?php if(isPhoto($message->file)): ?>
                                    <div class="w-100 my-2">
                                        <img class="img-fluid rounded" loading="lazy" style="height: 250px" src="<?php echo e($message->file); ?>">
                                    </div>
                                <?php elseif(isVideo($message->file)): ?>
                                    <div class="w-100 my-2">
                                        <video style="height: 250px" class="img-fluid rounded" controls>
                                            <source src="<?php echo e($message->file); ?>">
                                        </video>
                                    </div>
                                <?php elseif($message->file): ?>
                                    <div class="w-100 my-2">
                                        <a href="<?php echo e($message->file); ?>" class="bg-light p-2 rounded-pill" target="_blank" download><i class="fa fa-download"></i> 
                                            <?php echo e($message->file_name); ?>

                                        </a>
                                    </div>
                                <?php endif; ?>
                                <small class="text-muted w-100">Sent <em><?php echo e($message->created_at); ?></em></small>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php else: ?>
                        No messages to show
                    <?php endif; ?>
                </div>
                <div class="card-footer">
                    <form wire:submit.prevent="SendMessage" enctype="multipart/form-data">
                        <div wire:loading wire:target='SendMessage'>
                           ارسال الرساله. . . 
                        </div>
                        <div wire:loading wire:target="file">
                           تحميل الملف . . .
                        </div>
                        <?php if($file): ?>
                                <div class="mb-2">
                                   You have an uploaded file <button type="button" wire:click="resetFile" class="btn btn-danger btn-sm"><i class="fa fa-times"></i> Remove <?php echo e($file->getClientOriginalName()); ?></button>
                                </div>
                            <?php else: ?>
                               لا يوجد ملفات محملة
                            <?php endif; ?>
                        <div class="row">
                            <div class="col-md-7">
                                <input wire:model="messages" class="form-control input shadow-none w-100 d-inline-block" placeholder="اكتب هنا" <?php if(!$file): ?> required <?php endif; ?>>
                            </div>
                            <?php if(empty($file)): ?>
                                <div class="col-md-1">
                                    <button type="button" class=" btn btn-outline-secondary" id="file-area">
                                        <label>
                                            <i class="fa fa-file-upload"></i>
                                            <input type="file" wire:model="file" style="border:none;">
                                        </label>
                                    </button>
                                </div>
                                <?php endif; ?>
                            <div class="col-md-4">
                                <button class="btn btn-submit btn-hover  me-2 w-100"><i class="far fa-paper-plane"></i> ارسال</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php /**PATH C:\Users\Dell\Desktop\PROJECT صيدليتي\Pharmacy_Near_Me - Copy\resources\views/livewire/show.blade.php ENDPATH**/ ?>