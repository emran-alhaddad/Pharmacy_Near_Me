<!DOCTYPE html>
<html dir="rtl">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Profile</title>
    <link href="<?php echo e(asset('user/css/bootstrap.min.css')); ?>" rel="stylesheet">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css">
    <script src="<?php echo e(asset('user/js/jquery.min.js')); ?>"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>

    <style>
        :root {
            --black: #444;
            --light-color: #777;
            --box-shadow: .5rem .5rem 0 rgba(22, 160, 133, .2);
            --text-shadow: .4rem .4rem 0 rgba(0, 0, 0, .2);
            --border: .2rem solid var(--main-color);

            --main-color: #543ab7;
            --secondary-color: #00acc1;
            --hover-main: #817ecd;
            --hover-secondary: #9bb0dd;
            --bg-sec: #f2f2fa;

            --radius: .5rem;
        }

        * {
            font-family: 'Poppins', sans-serif;
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            outline: none;
            border: none;
            text-transform: capitalize;
            transition: all .2s ease-out;
            text-decoration: none;
        }

        html {
            font-size: 95%;
            overflow-x: hidden;
            scroll-padding-top: 7rem;
            scroll-behavior: smooth;
        }

        html::-webkit-scrollbar {
            width: 1rem;
        }

        html::-webkit-scrollbar-track {
            background: transparent;
        }

        html::-webkit-scrollbar-thumb {
            background: linear-gradient(60deg, rgba(84, 58, 183, 1) 0%, rgba(0, 172, 193, 1) 100%);
        }

        .btn,
        .bg-primary {

            border: var(--border);
            border-radius: var(--radius);
            box-shadow: var(--box-shadow);
            color: rgba(84, 58, 183, 1);
            cursor: pointer;
            text-align: center;
        }

        .btn:hover {
            background: var(--main-color);
            color: #fff;
            cursor: pointer;
        }

        .color-user {
            color: var(--black);
            padding: .2rem;
            text-decoration: none;
        }

        .color-user:hover {
            color: var(--main-color);
            ;
        }

        i {
            color: var(--main-color);
        }

        .log-btn {
            display: inline-block;
            margin-top: 1rem;
            padding: .7rem;
            border: var(--border);
            border-radius: var(--radius);
            color: var(--main-color);
            cursor: pointer;
        }

        .log-btn:hover {
            /* background-color: var(--hover-main); */
            cursor: pointer;
            /* color: #ffffff; */
        }

        .s-btn {
            width: 100%;
            padding: 1rem 1.2rem;
            font-size: 1.6rem;
            font-weight: 800;
            color: var(--black);
            border: solid 1px var(--main-color);
            margin: 1rem 0;
            text-transform: none;
            border-radius: var(--radius);
        }

        input[type="number"] {
            width: 49px;
            border: var(--border);
            text-align: center;
        }

        .back-to-top.btn-hover {
            position: fixed;
            z-index: 99999;
        }

        .back-to-top:hover {
            color: #fff;
        }

        *:focus {
            outline: none;
        }


        /*===== All Button Style =====*/

        .main-btn {
            display: inline-block;
            text-align: center;
            white-space: nowrap;
            vertical-align: middle;
            user-select: none;
            border: 0;
            padding: 16px 38px;
            font-weight: 600;
            font-size: 18px;
            border-radius: var(--radius);
            color: #fff;
            cursor: pointer;
            z-index: 5;
            background: var(--main-color);
            transition: all 0.4s ease-out 0s;
        }

        .main-btn:hover {
            color: #fff;
        }

        .btn-hover {
            position: relative;
            z-index: 1;
            overflow: hidden;
        }

        .btn-hover::after {
            content: '';
            position: absolute;
            width: 0%;
            height: 100%;
            background: rgba(255, 255, 255, 0.1);
            top: 0;
            left: 0;
            z-index: -1;
            transition: all 0.3s ease-out 0s;
        }

        .btn-hover:hover::after {
            width: 100%;
        }

    </style>
</head>

<body class="bg-light" style="color: rgb(102, 62, 96);">
    <main class="container">
        <!-- top nav start -->
        <?php echo $__env->make('includes.UserTopNav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- top nav end -->

        <!-- side Nav Start -->
        <?php echo $__env->make('includes.UserSideNav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- side Nav end -->

        <?php echo $__env->yieldContent('content'); ?>


        <!-- Edit user avater image model -->
        <div class="modal fade" id="avater-edit-model" tabindex="-1" aria-labelledby="exampleModalLabel"
            aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered">
                <div class="modal-content p-3">
                    <!-- model header -->
                    <div class="modal-headerd-flex justify-content-between align-items-center">
                        <h4 class="modal-title fw-bold text-center" id="exampleModalLabel">
                            تعديل صورة البروفايل
                        </h4>

                        <button type="button" class="btn-close" data-dismiss="modal" aria-label="Close"></button>
                    </div>

                    <!-- model body -->
                    <div class="modal-body">
                        <form action="<?php echo e(route('client-avater-update')); ?>" method="POST" class="g-3"
                            enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('put'); ?>
                            <div class="input-group mb-3">
                                <input type="file" name='avater' class="form-control" id="inputGroupFile02" />
                            </div>
                            <button type="submit" class="btn bg-primary text-white">
                                تعديل
                            </button>
                        </form>
                    </div>

                    <!-- model footer -->
                    <div class="modal-footer">

                    </div>
                </div>
            </div>
        </div>

        <!-- show compliant reply model -->
        <div class="modal fade" id="compliant-reply" tabindex="-1" aria-labelledby="exampleModalLabel2"
            aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered">
                <div class="modal-content p-3">
                    <!-- model header -->
                    <div class="modal-headerd-flex justify-content-between align-items-center">
                        <h4 class="modal-title fw-bold text-center" id="exampleModalLabel2">
                            الرد على الشكوى
                        </h4>
                        <button type="button" class="btn-close" data-dismiss="modal"></button>
                    </div>

                    <!-- model body -->
                    <div class="modal-body">

                        <p id="reply-text"></p>
                    </div>

                    <!-- model footer -->
                    <div class="modal-footer">
                        <button type="button" class="btn btn-primary text-light" data-dismiss="modal">تـــم</button>
                    </div>
                </div>
            </div>
        </div>
</body>

</html>
<?php /**PATH C:\Users\Dell\Desktop\PROJECT صيدليتي\Pharmacy_Near_Me - Copy\resources\views/layouts/masterUser.blade.php ENDPATH**/ ?>