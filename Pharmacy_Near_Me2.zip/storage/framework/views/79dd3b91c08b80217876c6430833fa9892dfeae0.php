
<?php $__env->startSection('admin_pages'); ?>


    <div class="wrapper bg-white">
        <div class="row  ">
            <div class="col-12 col-m-8 col-sm-8">
                <div class="card bg-white m-5">

                    <div class="card-header d-flex justify-content-between">
                        <h3>الرد على الشكوى</h3>
                    </div>
                    <div class="card-content">
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="alert alert-danger" role="alert"><?php echo e($error); ?></div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php if(session('error')): ?>
                            <div class="alert alert-danger" role="alert">
                                <?php echo e(session('error')); ?>

                            </div>
                        <?php endif; ?>
                        <?php if(session('status')): ?>
                            <div class="alert alert-success" role="alert">
                                <?php echo e(session('status')); ?>

                            </div>
                        <?php endif; ?>
                        <form action=<?php echo e(route('admin-create_Complaints', ['id' => $id])); ?> method="POST">
                            <div class="row g-3">

                                

                            </div>


                            <div class="row g-3">
                                <div class="mb-3 col-8">
                                    <label for="exampleInputLink" class="form-label">رد الشكوى</label>
                                    <textarea type="text" name="replay" class="form-control"></textarea>
                                </div>
                            </div>
                            <div class="row">
                                <div class="mb-3 col-4">
                                    <div class="custom-control custom-radio custom-control-inline">
                                        <input type="radio" id="customRadioInline1" name="orderMony"
                                            class="custom-control-input" checked value="client">
                                        <label class="custom-control-label" for="customRadioInline1">إعادة المبلغ
                                            للعميل</label>
                                    </div>
                                    <div class="custom-control custom-radio custom-control-inline">
                                        <input type="radio" id="customRadioInline2" name="orderMony"
                                            class="custom-control-input" value="pharmacy">
                                        <label class="custom-control-label" for="customRadioInline2">دفع للصيدلية</label>
                                    </div>
                                </div>
                            </div>


                            <button id="submit_button" type="submit" class="btn btn-primary">ارسال الرد</button>
                        </form>



                    </div>
                </div>
            </div>


        <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.masterAdmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Dell\Desktop\PROJECT صيدليتي\Pharmacy_Near_Me - Copy\resources\views/admin/Complaints/add_Complaints.blade.php ENDPATH**/ ?>