
<?php $__env->startSection('admin_pages'); ?>


<div class="wrapper bg-white">
    <div class="row  ">
        <div class="col-12 ">
        <div class="card bg-white m-5">

            <div class="card-header d-flex justify-content-between">
                <a href="/_admin/add_ads"><i class="fas fa-plus"></i></a>
                <h3>الاعلانات</h3>
            </div>
            <div class="card-content">
                <?php if(session('error')): ?>
                <div class="alert alert-danger" role="alert">
                    <?php echo e(session('error')); ?>

                </div>
            <?php endif; ?>
            <?php if(session('status')): ?>
                <div class="alert alert-success" role="alert">
                    <?php echo e(session('status')); ?>

                </div>
            <?php endif; ?>

                <table class="table">
                    <thead>
                        <tr>
                            <th> اسم الاعلان</th>
                            <th> رابط الموقع</th>
                            <th>تاريخ بداية الاعلان</th>
                            <th>تاريخ نهاية الاعلان</th>
                            <th>مكان الاعلان</th>
                            <th>صورة الاعلان</th>
                            <th>الحالة</th>
                            <th>العمليات</th>
                        </tr>
                    </thead>

                    <tbody>
                        <?php $__currentLoopData = $ads; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ad): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                        <td><?php echo e($ad->descripe); ?></td>
                        <td><?php echo e($ad->url); ?></td>
                        <td><?php echo e($ad->startAt); ?></td>
                        <td><?php echo e($ad->endAt); ?></td>
                        <td><?php echo e($ad->position); ?></td>
                        <td>  <img src=<?php echo e(asset("/uploads/ads/$ad->image")); ?> alt="avatar"
                                    class="rounded-circle img-fluid" style="width: 50px;"></td>


                                    <?php if($ad->is_active==1): ?>

                                    <td>  <a href=<?php echo e(route('admin-ads_activity', ['id' => $ad->id , 'stats'=>0])); ?>>   <button class="btn badge btn-success text-white" >مفعل</button></a></td>


                                      <?php else: ?>

                                        <td>  <a href=<?php echo e(route('admin-ads_activity', ['id' => $ad->id ,'stats'=>1])); ?>> <button class="btn badge btn-danger text-white" >موقف</button></a></td>

                                      <?php endif; ?>


                            <td>
                                <a href=<?php echo e(route('admin-edit_ads', ['id' => $ad->id])); ?> >    <button class="btn " ><i class="fas fa-pen" id="edit"></i></button></a>
                            <button class="btn" data-bs-toggle="modal" data-bs-target="#exampleModal<?php echo e($ad->id); ?>" id="delete"><i class="fas fa-trash"></i></button>

                                    <div class="modal"  id="exampleModal<?php echo e($ad->id); ?>"  tabindex="-1">
                                        <div class="modal-dialog">
                                            <div class="modal-content">
                                            <div class="modal-header">
                                                <h5 class="modal-title">حذف </h5>
                                            </div>
                                            <div class="modal-body">
                                                </p> هل تريد حقا حذف الاعلان ؟</p>
                                            </div>
                                            <div class="modal-footer">
                                                <button type="button" class="btn btn-danger" data-bs-dismiss="modal">لا</button>
                                                <a href=<?php echo e(route('admin-ads_activity', ['id' => $ad->id,'stats'=>0])); ?>  >        <button type="button" class="btn btn-primary">نعم</button></a>
                                            </div>
                                            </div>
                                        </div>
                                    </div>

                            </td>


                        </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>

                </table>

            </div>
        </div>
</div>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.masterAdmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Dell\Desktop\PROJECT صيدليتي\Pharmacy_Near_Me\resources\views/admin/ads/show_ads.blade.php ENDPATH**/ ?>