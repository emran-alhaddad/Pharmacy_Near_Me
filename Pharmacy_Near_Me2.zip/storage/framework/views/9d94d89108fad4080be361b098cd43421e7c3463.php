<!--====== HEADER PART START ======-->

<header class="header_area shadow" style="direction: rtl;">
    <div id="header_navbar" class="header_navbar " style="background-color: white; ">
        <div class="container position-relative">
            <div class="row align-items-center">
                <div class="col-xl-12">
                    <nav class="navbar navbar-expand-lg dir">
                        <a class="navbar-brand " href="<?php echo e(route('index')); ?>">
                            <img src="<?php echo e(asset('Front/assets/images/about/علاجي-01-3.svg')); ?>" id="logo"
                                clasd="btn-hover" alt="Logo">
                        </a>
                        <div class="collapse navbar-collapse sub-menu-bar" id="navbarSupportedContent">
                            <ul id="nav" class="navbar-nav">
                                <li class="nav-item">
                                    <a class="page-scroll active" href="<?php echo e(route('index')); ?>">الرئيسية</a>
                                </li>
                                <li class="nav-item">
                                    <a class="page-scroll active" href="<?php echo e(route('pharmacies')); ?>">الصيدليات</a>
                                </li>
                                <li class="nav-item">
                                    <a class="page-scroll active" href="<?php echo e(route('about')); ?>"> من نحن</a>
                                </li>
                                <li class="nav-item">
                                    <a class="page-scroll active" href="<?php echo e(route('contact')); ?>">تواصل معنا</a>
                                </li>
                            </ul>

                        </div>
                        <ul class="header-btn d-md-flex">

                            <!-- In LogIn Case  -->
                            <?php if(auth()->user()): ?>
                                <li>
                                    <a href="#" class="main-btn account-btn">
                                        <span class="d-md-none"><i class="lni lni-user"></i></span>
                                        <span class="d-none d-md-block">البروفايل</span>
                                    </a>
                                    <ul class="dropdown-nav dir" style="height: auto;">
                                        <?php if(auth()->user()->hasRole('admin')): ?>
                                            <li><a href="<?php echo e(route('admin-dashboard')); ?>">لوحة التحكم</a></li>
                                        <?php elseif(auth()->user()->hasRole('pharmacy')): ?>
                                            <li><a href="<?php echo e(route('pharmacy-dashboard')); ?>">لوحة التحكم</a></li>
                                        <?php else: ?>
                                            <li><a href="<?php echo e(route('client-dashboard')); ?>">لوحة التحكم</a></li>
                                        <?php endif; ?>

                                        <li><a href="<?php echo e(route('logout')); ?>">تسجيل خروج</a></li>
                                    </ul>
                                </li>
                            <?php else: ?>
                                <li>
                                    <a href="<?php echo e(route('login')); ?>"
                                        class="main-btn  d-none mr-sm-2 d-md-block btn-hover">دخول</a>
                                </li>
                            <?php endif; ?>


                        </ul>
                        <button class="navbar-toggler" type="button" data-toggle="collapse"
                            data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent"
                            aria-expanded="false" aria-label="Toggle navigation">
                            <span class="toggler-icon"></span>
                            <span class="toggler-icon"></span>
                            <span class="toggler-icon"></span>
                        </button>
                    </nav> <!-- navbar -->
                </div>
            </div> <!-- row -->
        </div> <!-- container -->
    </div> <!-- header navbar -->
</header>



<!--====== HEADER PART ENDS ======-->
<?php /**PATH C:\Users\Dell\Desktop\PROJECT صيدليتي\Pharmacy_Near_Me - Copy\resources\views/includes/FrontHeader.blade.php ENDPATH**/ ?>