

<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <div class="container">
            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('show', ['users' => $users, 'messages' => $messages, 'sender' => $sender])->html();
} elseif ($_instance->childHasBeenRendered('luuMH3x')) {
    $componentId = $_instance->getRenderedChildComponentId('luuMH3x');
    $componentTag = $_instance->getRenderedChildComponentTagName('luuMH3x');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('luuMH3x');
} else {
    $response = \Livewire\Livewire::mount('show', ['users' => $users, 'messages' => $messages, 'sender' => $sender]);
    $html = $response->html();
    $_instance->logRenderedChild('luuMH3x', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.masterUser3', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Dell\Desktop\PROJECT صيدليتي\Pharmacy_Near_Me - Copy\resources\views/user/chat/show.blade.php ENDPATH**/ ?>