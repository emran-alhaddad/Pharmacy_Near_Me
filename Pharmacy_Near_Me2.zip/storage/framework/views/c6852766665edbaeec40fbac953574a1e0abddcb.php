<!--====== FOOTER PART START ======-->
<footer class="footer-area col-12 shadow" style="direction: rtl;">
    <div class="widget-wrapper">
        <div class="container">
            <div class="row">
                <div class="col-xl-12 col-md-12">
                    <div class="footer-widget about">
                        <p class="text-center col-12">تم تصميمة بواسطة <a href="#">Taiz Pharmacy Team </a> جميع الحقوق محفوظة &copy; </p>
                        <ul class="social text-center align-content-center align-self-center">
                            <li><a href="#"><i class="lni lni-facebook-filled"></i></a></li>
                            <li><a href="#"><i class="lni lni-twitter-filled"></i></a></li>
                            <li><a href="#"><i class="lni lni-instagram-filled"></i></a></li>
                            <li><a href="#"><i class="lni lni-linkedin-original"></i></a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>


</footer>
<!--====== FOOTER PART ENDS ======-->
<?php /**PATH C:\Users\Dell\Desktop\PROJECT صيدليتي\Pharmacy_Near_Me\resources\views/includes/FrontFooter.blade.php ENDPATH**/ ?>