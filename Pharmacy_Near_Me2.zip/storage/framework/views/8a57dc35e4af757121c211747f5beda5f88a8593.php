<div id="wait-pay" class="tab-pane fade">
    <table class="table table-striped">
        <thead>
            <tr>
                <th scope="col">رقم الطلبية</th>
                <th scope="col">الصيدلية</th>
                <th scope="col">تاريخ الطلبية</th>
                <th scope="col">سعر الطلبية</th>
                <th scope="col">حالة الطلبية</th>
                <th scope="col">العمليات</th>
            </tr>
        </thead>
        <tbody id="request_body">
            <?php $__currentLoopData = $requests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $request): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($request->state == \App\Utils\RequestState::ACCEPTED): ?>
                    <tr>
                        <th scope="row"><?php echo e($loop->iteration); ?></th>
                        <td><?php echo e($request->pharmacy->user->name); ?></td>
                        <td><?php echo e($request->created_at->diffForHumans()); ?></td>
                        <td>
                            $<?php echo e(\App\Http\Controllers\Payment\PaymentController::getProducts($request->id)['total_price']); ?>

                        </td>
                        <td><span class="badge bg-warning text-dark" style="background-color:rgb(240, 225, 15);">في
                                انتضار الدفع</span></td>
                        <td><a class=" btn btn-submit text-light btn-hover me-2" href="javascript:void(0);"
                                data-bs-toggle="collapse" role="button" data-bs-target="#details<?php echo e($request->id); ?>">
                                عرض التفاصيل
                            </a></td>
                        <td><a class="btn btn-success" href="<?php echo e(route('user-payment', $request->id)); ?>">
                                دفع
                            </a></td>
                        <td><a href="<?php echo e(route('client-orders-reject', $request->id)); ?>" class="btn btn-danger">
                                رفض
                            </a></td>

                    </tr>

                    <tr>
                        <td colspan="6">
                            <div class=" collapse" id="details<?php echo e($request->id); ?>">
                                <div class="card card-body">
                                    <table class="table">
                                        <thead>
                                            <tr>
                                                <th scope="col">أسم/صورة العلاج</th>
                                                <th scope="col"> الكمية</th>
                                                <th scope="col">أقبل البدائل</th>
                                                <th scope="col">العمليات </th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php $__currentLoopData = $request->details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $requestDetails): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                    <td>
                                                        <?php if($requestDetails->drug_image): ?>
                                                            <li data-bs-toggle="tooltip" data-popup="tooltip-custom"
                                                                data-bs-placement="top" class="avatar pull-up"
                                                                title="صورة العلاج " style="list-style-type: none;">
                                                                <img src="<?php echo e(asset('uploads/requests/' . $requestDetails->drug_image)); ?>"
                                                                    alt="Avatar" class="rounded-circle image_show">
                                                            </li>
                                                        <?php endif; ?>
                                                        <strong><?php echo e($requestDetails->drug_title); ?></strong>
                                                    </td>
                                                    <td><?php echo e($requestDetails->quantity); ?></td>
                                                    <td>
                                                        <?php if($requestDetails->accept_alternative): ?>
                                                            <span class="badge bg-success text-light">
                                                                نعم
                                                            <?php else: ?>
                                                                <span class="badge bg-danger text-light">
                                                                    لا
                                                        <?php endif; ?>
                                                        </span>
                                                    </td>
                                                    <td><a class="btn btn-primary" href="javascript:void(0);"
                                                            data-bs-toggle="collapse" role="button"
                                                            data-bs-target="#reply<?php echo e($requestDetails->id); ?>">
                                                            عرض الرد
                                                        </a></td>
                                                </tr>

                                                <tr>
                                                    <td colspan="5">
                                                        <div class=" collapse"
                                                            id="reply<?php echo e($requestDetails->id); ?>">
                                                            <div class="card card-body">
                                                                <table class="table">
                                                                    <thead>
                                                                        <tr>
                                                                            <th scope="col">أسم/صورة العلاج</th>
                                                                            <th scope="col"> الكمية</th>
                                                                            <th scope="col">نوع الرد</th>
                                                                            <th scope="col">سعر العلاج </th>
                                                                            <th scope="col">قبول الرد </th>
                                                                        </tr>
                                                                    </thead>
                                                                    <tbody>
                                                                        <?php $__currentLoopData = $request->replies->details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $replyDetails): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                            <?php if($requestDetails->id == $replyDetails->request_details_id): ?>
                                                                                <tr>
                                                                                    <?php if($replyDetails->drug_price): ?>
                                                                                        <td>
                                                                                            <?php if($requestDetails->drug_image): ?>
                                                                                                <li data-bs-toggle="tooltip"
                                                                                                    data-popup="tooltip-custom"
                                                                                                    data-bs-placement="top"
                                                                                                    class="avatar pull-up"
                                                                                                    title="صورة العلاج "
                                                                                                    style="list-style-type: none;">
                                                                                                    <img src="<?php echo e(asset('uploads/requests/' . $requestDetails->drug_image)); ?>"
                                                                                                        alt="Avatar"
                                                                                                        class="rounded-circle image_show">
                                                                                                </li>
                                                                                            <?php endif; ?>
                                                                                            <strong><?php echo e($requestDetails->drug_title); ?></strong>
                                                                                        </td>
                                                                                        <td><?php echo e($requestDetails->quantity); ?>

                                                                                        </td>
                                                                                        <td><span
                                                                                                class="badge bg-primary text-light">اساسي</span>
                                                                                        </td>
                                                                                        <td><?php echo e($replyDetails->drug_price); ?>

                                                                                        </td>
                                                                                    <?php else: ?>
                                                                                        <td>
                                                                                            <?php if($replyDetails->alt_drug_image): ?>
                                                                                                <li data-bs-toggle="tooltip"
                                                                                                    data-popup="tooltip-custom"
                                                                                                    data-bs-placement="top"
                                                                                                    class="avatar pull-up"
                                                                                                    title="صورة العلاج "
                                                                                                    style="list-style-type: none;">
                                                                                                    <img src="<?php echo e(asset('uploads/replies/' . $replyDetails->alt_drug_image)); ?>"
                                                                                                        alt="Avatar"
                                                                                                        class="rounded-circle image_show">
                                                                                                </li>
                                                                                            <?php endif; ?>
                                                                                            <strong><?php echo e($replyDetails->alt_drug_title); ?></strong>
                                                                                        </td>
                                                                                        <td><?php echo e($requestDetails->quantity); ?>

                                                                                        </td>
                                                                                        <td><span
                                                                                                class="badge bg-secondary text-light">بديل</span>
                                                                                        </td>
                                                                                        <td><?php echo e($replyDetails->alt_drug_price); ?>

                                                                                        </td>
                                                                                    <?php endif; ?>


                                                                                    <td>
                                                                                        <input type="checkbox" name=""
                                                                                            data-id="<?php echo e($replyDetails->id); ?>"
                                                                                            class="replyDetailsState"
                                                                                            <?php if($replyDetails->state == \App\Utils\ReplyState::ACCEPTED): ?> checked <?php endif; ?>>
                                                                                    </td>
                                                                                </tr>
                                                                            <?php endif; ?>
                                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                    </tbody>
                                                                </table>
                                                            </div>
                                                        </div>
                                                    </td>
                                                </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </td>
                    </tr>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"
integrity="sha256-/xUj+3OJU5yExlq6GSYGSHk7tPXikynS7ogEvDej/m4=" crossorigin="anonymous"></script>
<script>
    $(".replyDetailsState").change(function() {
        var state = "<?php echo e(\App\Utils\ReplyState::REJECTED); ?>";
        if (this.checked)
            state = "<?php echo e(\App\Utils\ReplyState::ACCEPTED); ?>";

        var url = "/client/reply-details/" + $(this).attr('data-id') + "/toggle/" + state;
        var item = $(this);
        $.ajax({
            method: 'get',
            url: url,
            success: function(data) {
                console.log($(item.parents().eq(13).prev().children()[3]));
            }
        });
    });
</script>
<?php /**PATH C:\Users\Dell\Desktop\PROJECT صيدليتي\Pharmacy_Near_Me\resources\views/user/state/wait-payment.blade.php ENDPATH**/ ?>