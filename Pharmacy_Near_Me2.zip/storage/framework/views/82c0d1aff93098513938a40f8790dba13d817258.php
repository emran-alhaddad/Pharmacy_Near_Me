


<?php $__env->startSection('content'); ?>
<!--====== BANNER PART START ======-->
<section class="banner-area bg_cover shadow" style="direction: rtl;">
    <div class="container">
        <div class="row">
            <div class="col-lg-6">
                <div class="banner-content">
                    <h1 class="text-white">جميع صيدليات علاجي</h1>
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="<?php echo e(route('index')); ?>"> الرئيسية</a></li>
                            <li class="breadcrumb-item active" aria-current="page"> الصيدليات </li>
                        </ol>
                    </nav>
                </div>
            </div>
        </div>
    </div>
</section>
<!--====== BANNER PART END ======-->

<!-- Search Pharmacy section start -->
<?php echo $__env->make('includes.FrontSearch', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- Search Pharmacy section ends -->


<!--====== PHARMACIES PART START ======-->
<section class="pharmacy-area my-5 py-5" style="direction: rtl;">
    <div class="container">
        <!-- pharmacy wrapper -->
        <div class="pharmacy-wrapper">
            <div class="row">
                <!-- left-wrapper  -->
                <div class="col-lg-8">
                    <div class="left-wrapper">
                        <div class="tab-content" id="myTabContent">
                            <div class="tab-pane fade show active" id="grid" role="tabpanel" aria-labelledby="grid-tab">
                                <div class="row">
                                    <?php $__empty_1 = true; $__currentLoopData = $pharmacies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pharmacy): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                        <div class="col-lg-6 col-md-6 ">
                                            <div class="single-pharmacy col-12 shadow p-3 bg-white radius">
                                                <div class="pharmacy-img p-2 col-12 ">
                                                    <a href="<?php echo e(route('detailes', $pharmacy->id)); ?>">
                                                        <img src="<?php echo e(asset('uploads/avaters/pharmacy/'.$pharmacy->avater)); ?>"
                                                            alt="<?php echo e($pharmacy->name); ?>" class="radius col-12 ">
                                                    </a>
                                                </div>

                                                <div class="pharmacy-content ">
                                                    <h3 class="name p-1 pr-4"><a href="<?php echo e(route('detailes', $pharmacy->id)); ?>">
                                                            <?php echo e($pharmacy->name); ?> </a></h3>
                                                    <ul class="address p-2 pr-4">
                                                        <li>
                                                            <a href="javascript:void(0)"><i
                                                                        class="lni lni-map-marker"></i> <?php echo e($pharmacy->Cname); ?>

                                                                    -  <?php echo e($pharmacy->Zname); ?></a>
                                                        </li>
                                                    </ul>
                                                    <div class="pharmacy-bottom m-1">
                                                        <a href="<?php echo e(route('add-order',$pharmacy->id)); ?>" class="main-btn col-12 p-2 btn-hover shadow"> تقديم طلب

                                                        </a>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                        <div class="alert alert-danger" role="alert">
                                            لا يوجد صيدليات مطابقة للبحث
                                            </div>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- sidebar wrapper  -->
                <div class="col-lg-4">
                    <div class="sidebar-wrapper">
                        <!-- Pagination -->
                        <div class="box-style social-box shadow col-12 d-flex justify-content-between"style="color: var(--main-color);">
                            <h3 class="">عرض المزيد </h3>
                            <?php echo e($pharmacies->links()); ?>

                            
                        </div>
                        <!--/ Basic Pagination -->
                        <!-- adds box -->
                        <div class="box-style add-box shadow">
                            <h3 class="mb-30">اعلانات</h3>
                            <?php $__currentLoopData = $ads; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ad): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="image">
                                <a href="javascript:void(0)" class="d-block">
                                    <img src="<?php echo e(asset("/uploads/ads/$ad->image")); ?>"  alt="" class="w-100">
                                </a>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!--====== PHARMACIES PART END ======-->




<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.masterFront', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Dell\Desktop\PROJECT صيدليتي\Pharmacy_Near_Me - Copy\resources\views/front/pharmacies.blade.php ENDPATH**/ ?>