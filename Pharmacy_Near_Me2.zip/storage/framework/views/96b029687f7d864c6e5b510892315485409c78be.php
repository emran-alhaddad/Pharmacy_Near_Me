

<?php $__env->startSection('content'); ?>


    <div class="layout-wrapper layout-content-navbar">

        <div class="layout-container">

            <div class="layout-page">


                <!-- Content wrapper -->
                <div class="content-wrapper">
                    <!-- Content -->

                    <div class="container-xxl flex-grow-1 container-p-y">


                        <div class="row">
                            <div class="col-xl-12">
                                <div class="nav-align-top mb-4">
                                    <ul class="nav nav-tabs" role="tablist">
                                        <li class="nav-item">
                                            <button type="button" class="nav-link active" role="tab" data-bs-toggle="tab"
                                                data-bs-target="#wait-accept" aria-controls="navs-top-accept"
                                                aria-selected="true"> في انتظار القبول
                                            </button>
                                        </li>
                                        <li class="nav-item">
                                            <button type="button" class="nav-link" role="tab" data-bs-toggle="tab"
                                                data-bs-target="#wait-pay" aria-controls="navs-top-paym"
                                                aria-selected="false">
                                                في انتظار الدفع
                                            </button>
                                        </li>
                                        <li class="nav-item">
                                            <button type="button" class="nav-link" role="tab" data-bs-toggle="tab"
                                                data-bs-target="#wait-delivery" aria-controls="navs-top-delevry"
                                                aria-selected="false">
                                                في انتظار التوصيل
                                            </button>
                                        </li>
                                        <li class="nav-item">
                                            <button type="button" class="nav-link" role="tab" data-bs-toggle="tab"
                                                data-bs-target="#done" aria-controls="navs-top-done" aria-selected="false">
                                                مكتملة
                                            </button>
                                        </li>
                                        <li class="nav-item">
                                            <button type="button" class="nav-link" role="tab" data-bs-toggle="tab"
                                                data-bs-target="#rejected" aria-controls="navs-top-none"
                                                aria-selected="false">
                                                غير متوفره
                                            </button>
                                        </li>
                                    </ul>





                                    <div class="tab-content">
                                        <?php echo $__env->make('user.state.wait-acceptance', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                        <?php echo $__env->make('user.state.wait-payment', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                        <?php echo $__env->make('user.state.wait-delivery', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                        <?php echo $__env->make('user.state.completed', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                        <?php echo $__env->make('user.state.rejected', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                    </div>



                                </div>
                            </div>

                        </div>


                    </div>

                </div>

            </div>


        </div>
    </div>
    </div>

    <!-- addCompliant Modal -->
    <div id="addCompliant" class="modal fade" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel"> اضافة شكوى</h5>

                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>

                <div class="modal-body">

                    <?php $__errorArgs = ['error'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="alert alert-danger" role="alert">
                            <?php echo e($message); ?>

                        </div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                    <?php $__errorArgs = ['status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e($message); ?>

                        </div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                    <form action="<?php echo e(route('client-compliants-store')); ?>" method="POST" class="g-3">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="order" id="order" />
                        <input type="hidden" name="pharmacy_id" id="pharmacy_id" />
                        <div class="row">
                            <div class="col-sm-3">
                                <h6 class="mb-0"> المشتكى عليه </h6>
                            </div>
                            <div class="col-sm-9 text-secondary">
                                <div class="input-group mb-3">

                                    <div class="dropdown col-12">
                                        <select id="pharmacy" name="pharmacy" disabled class=" rounded form-control">
                                            <?php $__currentLoopData = $pharmacies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pharmacy): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($pharmacy->user_id); ?>">
                                                    <?php echo e($pharmacy->user->name); ?>

                                                </option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                        </select>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <hr>

                        <div class="row">
                            <div class="col-sm-3">
                                <h6 class="mb-0">نص الشكوى </h6>
                            </div>
                            <div class="col-sm-9 text-secondary">
                                <div class="input-group mb-3 rounded">
                                    <textarea value="<?php echo e(old('message')); ?>" name="message"
                                        class="form-control rounded <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-danger <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">

                            </textarea>
                                    <?php $__errorArgs = ['message'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-feedback d-block">
                                            <?php echo e($message); ?>

                                        </div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                                </div>
                            </div>
                        </div>
                        <hr>

                        <div class="row">
                            <button class="btn-danger radius text-center p-2 col-12 mt-2" type="submit">
                                ارسال الشكوى
                            </button>
                        </div>
                    </form>
                </div>

            </div>

        </div>
    </div>

    <script>
  
    function reject(order, pharmacy) {
        $('#order').val(order);
        $('#pharmacy_id').val(pharmacy);
        $('#pharmacy').val(pharmacy).change();
    }
  
     
    <?php if(session('tapState')): ?>
    $(document).ready(function(){
        $("button[data-bs-target=\'#<?php echo e(session('tapState')); ?>\']").trigger('click');

    });

    <?php endif; ?>   
   


        // <?php if(session('tapState')): ?>
        //     $(document).ready(function() {
        //         $("button[data-bs-target=\'#<?php echo e(session('tapState')); ?>\']").trigger("click");
        //     });
        // <?php endif; ?>
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.masterUser2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Dell\Desktop\PROJECT صيدليتي\Pharmacy_Near_Me\resources\views/user/myorder.blade.php ENDPATH**/ ?>