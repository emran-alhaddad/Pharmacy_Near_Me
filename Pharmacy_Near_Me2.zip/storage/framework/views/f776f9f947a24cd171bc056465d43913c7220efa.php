
<?php $__env->startSection('admin_pages'); ?>
    <!-- Content -->
    <div class="wrapper bg-white">
        <div class="row">

            <div class=" mt-5" id="">
                <div class="card">
                    <div class="table-responsive text-nowrap">
                        <!-- Order clint  -->
                        <table class="table table-hover shadow">
                            <thead>
                                <tr>

                                    <td> <a class="btn btn-primary" href=<?php echo e(route('admin-add_Complaints',['id'=>$com->id])); ?>

                                     role="button">
                                            <i class="bx bx-plus-circle me-1"></i> إضافة رد على الشكوى</a>
                                    </td>
                                    <td> <a class="dropdown-item" href="javascript:void(0);" data-bs-toggle="modal"
                                            data-bs-target="#" role="button">
                                            <i class="bx bx-plus-circle me-1"></i> فتح محادثة</a>
                                    </td>

                                </tr>
                            </thead>
                        </table>
                        <!-- Order clint  -->
                        <!-- Order Details  -->
                        <div class=" m-4 shadow" id="">
                            <div class="card">
                                <h5 class="card-header"> تفاصيل الطلبية</h5>
                                <div class="table-responsive text-nowrap">
                                    <table class="table table-hover">
                                        <thead>
                                            <tr>
                                                <th>الرقم</th>
                                                <th>اسم / صورة الدواء</th>
                                                <th>الكمية</th>
                                                <th>قبول البدائل</th>
                                                <th>تقديم عرض</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php $__currentLoopData = $request->details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $requestDetails): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                    <td><i class="fab fa-angular fa-lg text-danger me-3"></i>
                                                        <strong><?php echo e($loop->iteration); ?></strong>
                                                    </td>
                                                    <td>
                                                        <?php if($requestDetails->drug_image): ?>
                                                            <li data-bs-toggle="tooltip" data-popup="tooltip-custom"
                                                                data-bs-placement="top" class="avatar pull-up"
                                                                title="صورة العلاج " style="list-style-type: none;">
                                                                <img src="<?php echo e(asset('uploads/requests/' . $requestDetails->drug_image)); ?>"
                                                                    alt="Avatar" class="rounded-circle image_show">
                                                            </li>
                                                        <?php endif; ?>
                                                        <strong><?php echo e($requestDetails->drug_title); ?></strong>
                                                    </td>
                                                    <td><i class="fab fa-angular fa-lg text-danger me-3"></i>
                                                        <strong><?php echo e($requestDetails->quantity); ?></strong>
                                                    </td>

                                                    <?php if($requestDetails->accept_alternative): ?>
                                                        <td><span class="badge bg-label-success me-1">نعم</span></td>
                                                    <?php else: ?>
                                                        <td><span class="badge bg-label-danger me-1">لا</span></td>
                                                    <?php endif; ?>
                                                    <?php if($request->state == \App\Utils\RequestState::WAIT_ACCEPTANCE): ?>
                                                        <td> <a class="dropdown-item" onclick="$('#req_det_id').val('<?php echo e($requestDetails->id); ?>');
                                                                                        <?php if($requestDetails->accept_alternative): ?> $('#alternative').css('visibility','visible');
                                                                <?php else: ?>
                                                                $('#alternative').css('visibility','hidden'); <?php endif; ?>
                                                                                        " href="javascript:void(0);"
                                                                data-bs-toggle="modal" data-bs-target="#basicModal"
                                                                role="button"><i class="bx bx-plus-circle me-1"></i> عرض
                                                                سعر</a>
                                                        </td>
                                                    <?php endif; ?>
                                                </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                        <!-- /Order Details  -->

                        <!-- added replies -->
                        <div class=" m-4 shadow">
                            <div class="alert_msg alert alert-danger mt-2 mb-2" style="display:none" role="alert">

                            </div>
                            <?php if(session('error')): ?>
                                <div class="alert alert-danger mt-2 mb-2" role="alert">
                                    <?php echo e(session('error')); ?>

                                </div>
                            <?php endif; ?>
                            <?php if(session('status')): ?>
                                <div class="alert alert-success mt-2 mb-2" role="alert">
                                    <?php echo e(session('status')); ?>

                                </div>
                            <?php endif; ?>
                            <div id="success_msg" class="alert alert-success mt-2 mb-2" style="display:none" role="alert">

                            </div>
                            <div class="card">
                                <h5 class="card-header">الردود المضافة </h5>
                                <div class="table-responsive text-nowrap">
                                    <table class="table table-hover">
                                        <thead>
                                            <tr>
                                                <th>اسم / صورة الدواء</th>
                                                <th>الكمية</th>
                                                <th>السعر</th>
                                                <th> نوع الرد</th>
                                            </tr>
                                        </thead>
                                        <?php if($request->state != \App\Utils\RequestState::WAIT_ACCEPTANCE): ?>
                                            <tbody>
                                                <?php $__currentLoopData = $request->replies->details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $replyDetails): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <?php
                                                        $requestDetails = $request->details->where('id', '=', $replyDetails->request_details_id)->first();
                                                    ?>
                                                    <?php if($replyDetails->request_details_id == $requestDetails->id): ?>
                                                        <tr>
                                                            <?php if($replyDetails->drug_price): ?>
                                                                <td>
                                                                    <?php if($requestDetails->drug_image): ?>
                                                                        <li data-bs-toggle="tooltip"
                                                                            data-popup="tooltip-custom"
                                                                            data-bs-placement="top" class="avatar pull-up"
                                                                            title="صورة العلاج "
                                                                            style="list-style-type: none;">
                                                                            <img src="<?php echo e(asset('uploads/requests/' . $requestDetails->drug_image)); ?>"
                                                                                alt="Avatar"
                                                                                class="rounded-circle image_show">
                                                                        </li>
                                                                    <?php endif; ?>
                                                                    <strong><?php echo e($requestDetails->drug_title); ?></strong>
                                                                </td>
                                                                <td><strong><?php echo e($requestDetails->quantity); ?></strong>
                                                                </td>
                                                                <td><strong><?php echo e($replyDetails->drug_price); ?></strong></td>

                                                                <td><i class='fab fa-angular fa-lg text-success me-3'></i>
                                                                    <strong>اساسي </strong>
                                                                </td>
                                                            <?php else: ?>
                                                                <td>
                                                                    <?php if($replyDetails->alt_drug_image): ?>
                                                                        <li data-bs-toggle="tooltip"
                                                                            data-popup="tooltip-custom"
                                                                            data-bs-placement="top" class="avatar pull-up"
                                                                            title="صورة العلاج "
                                                                            style="list-style-type: none;">
                                                                            <img src="<?php echo e(asset('uploads/replies/' . $replyDetails->alt_drug_image)); ?>"
                                                                                alt="Avatar"
                                                                                class="rounded-circle image_show">
                                                                        </li>
                                                                    <?php endif; ?>
                                                                    <strong><?php echo e($replyDetails->alt_drug_title); ?></strong>
                                                                </td>
                                                                <td><strong><?php echo e($requestDetails->quantity); ?></strong>
                                                                </td>
                                                                <td><strong><?php echo e($replyDetails->alt_drug_price); ?></strong>
                                                                </td>
                                                                <td><i class='fab fa-angular fa-lg text-danger me-3'></i>
                                                                    <strong>بديل </strong>
                                                                </td>
                                                            <?php endif; ?>
                                                        </tr>
                                                    <?php endif; ?>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </tbody>
                                        <?php endif; ?>

                                        <tbody id="order_details_table">

                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                        <!-- /added replies -->
                    </div>
                </div>
            </div>
            <!-- Order Details  -->
        </div>
    </div>







<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.masterAdmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Dell\Desktop\PROJECT صيدليتي\Pharmacy_Near_Me - Copy\resources\views/admin/Complaints/compliant-orders.blade.php ENDPATH**/ ?>