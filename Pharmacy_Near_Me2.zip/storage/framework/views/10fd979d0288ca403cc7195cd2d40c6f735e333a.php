
<?php $__env->startSection('admin_pages'); ?>


<div class="wrapper bg-white">
    <div class="row  ">
        <div class="col-12 col-m-12 col-sm-12">
        <div class="card bg-white m-5">

        <div class="card-header d-flex justify-content-between">
                    <h3>اضافة خدمة</h3>
        </div>

        <div class="card-content">
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="alert alert-danger" role="alert"><?php echo e($error); ?></div>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php if(session('error')): ?>
            <div class="alert alert-danger" role="alert">
                <?php echo e(session('error')); ?>

            </div>
        <?php endif; ?>
        <?php if(session('status')): ?>
            <div class="alert alert-success" role="alert">
                <?php echo e(session('status')); ?>

            </div>
        <?php endif; ?>
        <form method="POST" action="<?php echo e(route('admin-store_Service')); ?> " enctype="multipart/form-data">

                        <div class="row g-3">

                                <div class="mb-3 col-6">
                                    <label for="exampleInputName" class="form-label">عنوان الخدمة</label>
                                    <input type="text" name="title" class="form-control" id="exampleInputName">
                                </div>

                                <div class="mb-3 col-6">
                                    <label for="formFile" class="form-label">صورة الخدمة</label>
                                    <input class="form-control" name="image" type="file" id="formFile">
                                </div>

                                <div class="mb-3 col-12">
                                    <label for="formFile" class="form-label">وصف الخدمة</label>
                                    <input class="form-control" name="descripe" type="textarea" id="formFile">
                                </div>



                        </div>



                        <button  id="submit_button"  type="submit" class="btn btn-primary">اضافة</button>
                </form>

</div>
</div>
</div>
</div>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.masterAdmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Dell\Desktop\PROJECT صيدليتي\Pharmacy_Near_Me\resources\views/admin/WebSiteSetting/Add_Service.blade.php ENDPATH**/ ?>