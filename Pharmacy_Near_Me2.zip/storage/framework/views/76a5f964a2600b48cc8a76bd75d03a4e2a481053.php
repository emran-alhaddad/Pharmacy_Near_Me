


<?php $__env->startSection('content'); ?>
<div class="container">
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('message', ['users' => $users, 'messages' => $messages ?? null])->html();
} elseif ($_instance->childHasBeenRendered('rYWp9tr')) {
    $componentId = $_instance->getRenderedChildComponentId('rYWp9tr');
    $componentTag = $_instance->getRenderedChildComponentTagName('rYWp9tr');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('rYWp9tr');
} else {
    $response = \Livewire\Livewire::mount('message', ['users' => $users, 'messages' => $messages ?? null]);
    $html = $response->html();
    $_instance->logRenderedChild('rYWp9tr', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.masterUser3', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Dell\Desktop\PROJECT صيدليتي\Pharmacy_Near_Me - Copy\resources\views/user/chat/home.blade.php ENDPATH**/ ?>