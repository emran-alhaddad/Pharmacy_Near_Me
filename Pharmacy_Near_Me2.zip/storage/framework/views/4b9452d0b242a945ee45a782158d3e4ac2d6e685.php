<div id="rejected" class="tab-pane fade in">
    <table class="table table-striped">
        <thead>
            <tr>
                <th scope="col">رقم الطلبية</th>
                <th scope="col">الصيدلية</th>
                <th scope="col">تاريخ الطلبية</th>
                <th scope="col">حالة الطلبية</th>
                <th scope="col"></th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $requests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $request): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($request->state == \App\Utils\RequestState::REJECTED): ?>
                    <tr>
                        <th scope="row"><?php echo e($loop->iteration); ?></th>
                        <td><?php echo e($request->pharmacy->user->name); ?></td>
                        <td><?php echo e($request->created_at->diffForHumans()); ?></td>
                        <td><span class="badge bg-warning text-dark" style="background-color: brown;">غير متوفرة</span>
                        </td>
                        <td><a class=" btn btn-submit btn-hover text-light me-2" data-bs-toggle="collapse" role="button"
                                data-bs-target="#details<?php echo e($request->id); ?>">
                                عرض التفاصيل
                            </a></td>
                    </tr>

                    <tr>
                        <td colspan="5">
                            <div class="collapse" id="details<?php echo e($request->id); ?>">
                                <div class="card card-body">
                                    <table class="table">
                                        <thead>
                                            <tr>
                                                <th scope="col">أسم/صورة العلاج</th>
                                                <th scope="col"> الكمية</th>
                                                <th scope="col">أقبل البدائل</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php $__currentLoopData = $request->details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $details): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                    <td>
                                                        <?php if($details->drug_image): ?>
                                                            <li data-bs-toggle="tooltip" data-popup="tooltip-custom"
                                                                data-bs-placement="top" class="avatar pull-up"
                                                                title="صورة العلاج " style="list-style-type: none;">
                                                                <img src="<?php echo e(asset('uploads/requests/' . $details->drug_image)); ?>"
                                                                    alt="Avatar" class="rounded-circle image_show">
                                                            </li>
                                                        <?php endif; ?>
                                                        <strong><?php echo e($details->drug_title); ?></strong>
                                                    </td>
                                                    <td><?php echo e($details->quantity); ?></td>
                                                    <td>
                                                        <?php if($details->accept_alternative): ?>
                                                            <span class="badge bg-success text-light">
                                                                نعم
                                                            <?php else: ?>
                                                                <span class="badge bg-danger text-light">
                                                                    لا
                                                        <?php endif; ?>
                                                        </span>
                                                    </td>
                                                </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </td>
                    </tr>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



        </tbody>
    </table>
</div>
<?php /**PATH C:\Users\Dell\Desktop\PROJECT صيدليتي\Pharmacy_Near_Me - Copy\resources\views/user/state/rejected.blade.php ENDPATH**/ ?>