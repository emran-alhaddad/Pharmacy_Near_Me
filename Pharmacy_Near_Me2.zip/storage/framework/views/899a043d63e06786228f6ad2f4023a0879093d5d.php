<div id="wait-delivery" class="tab-pane fade">
    <table class="table table-striped">
        <thead>
            <tr>
                <th scope="col">رقم الطلبية</th>
                <th scope="col">الصيدلية</th>
                <th scope="col">تاريخ الطلبية</th>
                <th scope="col">سعر الطلبية</th>
                <th scope="col">حالة الطلبية</th>
                <th scope="col">العمليات</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $requests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $request): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($request->state == \App\Utils\RequestState::WAIT_DELIVERY): ?>
                    <tr>
                        <th scope="row"><?php echo e($loop->iteration); ?></th>
                        <td><?php echo e($request->pharmacy->user->name); ?></td>
                        <td><?php echo e($request->created_at->diffForHumans()); ?></td>
                        <td>
                            <?php echo e($request->replies->details->sum('drug_price')); ?>

                        </td>
                        <td><span class="badge bg-warning text-dark" style="background-color:rgb(195, 216, 161);">في
                                انتضار التوصيل</span></td>
                        <td><a class=" btn btn-submit text-light btn-hover text-light me-2" data-bs-toggle="collapse" role="button"
                                data-bs-target="#details<?php echo e($request->id); ?>" aria-expanded="false"
                                aria-controls="collapseExample">
                                عرض التفاصيل
                            </a>
                            <button type="button" class="btn btn-danger btn-hover me-2 " data-bs-toggle="modal"
                                data-bs-target="#addCompliant"
                                onclick="reject(<?php echo e($request->id); ?>,<?php echo e($request->pharmacy_id); ?>)">
                                تقديم شكوى
                            </button>
                            <a class=" btn btn-success btn-hover text-light me-2"
                                href="<?php echo e(route('client-orders-delivered', $request->id)); ?>">
                                تم التوصيل
                            </a>

                        </td>
                    </tr>

                    <tr>
                        <td colspan="6">
                            <div class=" collapse" id="details<?php echo e($request->id); ?>">
                                <div class="card card-body">
                                    <table class="table">
                                        <thead>
                                            <tr>
                                                <th scope="col">أسم/صورة العلاج</th>
                                                <th scope="col"> الكمية</th>
                                                <th scope="col">أقبل البدائل</th>
                                                <th scope="col">العمليات </th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php $__currentLoopData = $request->details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $requestDetails): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                    <td>
                                                        <?php if($requestDetails->drug_image): ?>
                                                            <li data-bs-toggle="tooltip" data-popup="tooltip-custom"
                                                                data-bs-placement="top" class="avatar pull-up"
                                                                title="صورة العلاج " style="list-style-type: none;">
                                                                <img src="<?php echo e(asset('uploads/requests/' . $requestDetails->drug_image)); ?>"
                                                                    alt="Avatar" class="rounded-circle image_show">
                                                            </li>
                                                        <?php endif; ?>
                                                        <strong><?php echo e($requestDetails->drug_title); ?></strong>
                                                    </td>
                                                    <td><?php echo e($requestDetails->quantity); ?></td>
                                                    <td>
                                                        <?php if($requestDetails->accept_alternative): ?>
                                                            <span class="badge bg-success text-light">
                                                                نعم
                                                            <?php else: ?>
                                                                <span class="badge bg-danger text-light">
                                                                    لا
                                                        <?php endif; ?>
                                                        </span>
                                                    </td>
                                                    <td><a class="btn btn-primary" data-bs-toggle="collapse"
                                                            href="#reply<?php echo e($requestDetails->id); ?>" role="button"
                                                            aria-expanded="false" aria-controls="collapseExample">
                                                            عرض الرد
                                                        </a></td>
                                                </tr>

                                                <tr>
                                                    <td colspan="5">
                                                        <div class=" collapse"
                                                            id="reply<?php echo e($requestDetails->id); ?>">
                                                            <div class="card card-body">
                                                                <table class="table">
                                                                    <thead>
                                                                        <tr>
                                                                            <th scope="col">أسم/صورة العلاج</th>
                                                                            <th scope="col"> الكمية</th>
                                                                            <th scope="col">نوع الرد</th>
                                                                            <th scope="col">سعر العلاج </th>
                                                                            <th scope="col">قبول الرد </th>
                                                                        </tr>
                                                                    </thead>
                                                                    <tbody>
                                                                        <?php $__currentLoopData = $request->replies->details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $replyDetails): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                            <?php if($requestDetails->id == $replyDetails->request_details_id): ?>
                                                                                <tr>
                                                                                    <?php if($replyDetails->drug_price): ?>
                                                                                        <td>
                                                                                            <?php if($requestDetails->drug_image): ?>
                                                                                                <li data-bs-toggle="tooltip"
                                                                                                    data-popup="tooltip-custom"
                                                                                                    data-bs-placement="top"
                                                                                                    class="avatar pull-up"
                                                                                                    title="صورة العلاج "
                                                                                                    style="list-style-type: none;">
                                                                                                    <img src="<?php echo e(asset('uploads/requests/' . $requestDetails->drug_image)); ?>"
                                                                                                        alt="Avatar"
                                                                                                        class="rounded-circle image_show">
                                                                                                </li>
                                                                                            <?php endif; ?>
                                                                                            <strong><?php echo e($requestDetails->drug_title); ?></strong>
                                                                                        </td>
                                                                                        <td><?php echo e($requestDetails->quantity); ?>

                                                                                        </td>
                                                                                        <td><span
                                                                                                class="badge bg-primary text-light">اساسي</span>
                                                                                        </td>
                                                                                        <td><?php echo e($replyDetails->drug_price); ?>

                                                                                        </td>
                                                                                    <?php else: ?>
                                                                                        <td>
                                                                                            <?php if($replyDetails->alt_drug_image): ?>
                                                                                                <li data-bs-toggle="tooltip"
                                                                                                    data-popup="tooltip-custom"
                                                                                                    data-bs-placement="top"
                                                                                                    class="avatar pull-up"
                                                                                                    title="صورة العلاج "
                                                                                                    style="list-style-type: none;">
                                                                                                    <img src="<?php echo e(asset('uploads/replies/' . $replyDetails->alt_drug_image)); ?>"
                                                                                                        alt="Avatar"
                                                                                                        class="rounded-circle image_show">
                                                                                                </li>
                                                                                            <?php endif; ?>
                                                                                            <strong><?php echo e($replyDetails->alt_drug_title); ?></strong>
                                                                                        </td>

                                                                                        <td><?php echo e($requestDetails->quantity); ?>

                                                                                        </td>
                                                                                        <td><span
                                                                                                class="badge bg-secondary text-light">بديل</span>
                                                                                        </td>
                                                                                        <td><?php echo e($replyDetails->alt_drug_price); ?>

                                                                                        </td>
                                                                                    <?php endif; ?>
                                                                                    <?php if($replyDetails->state == \App\Utils\ReplyState::ACCEPTED): ?>
                                                                                        <td>
                                                                                            <span
                                                                                                class="badge bg-success text-light">تم
                                                                                                قبول الرد</span>
                                                                                        </td>
                                                                                    <?php else: ?>
                                                                                        <td>
                                                                                            <span
                                                                                                class="badge bg-danger text-light">تم
                                                                                                رفض الرد</span>
                                                                                        </td>
                                                                                    <?php endif; ?>
                                                                                </tr>
                                                                            <?php endif; ?>
                                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                    </tbody>
                                                                </table>
                                                            </div>
                                                        </div>
                                                    </td>
                                                </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </td>
                    </tr>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>

</div>
<?php /**PATH C:\Users\Dell\Desktop\PROJECT صيدليتي\Pharmacy_Near_Me - Copy\resources\views/user/state/wait-delivery.blade.php ENDPATH**/ ?>