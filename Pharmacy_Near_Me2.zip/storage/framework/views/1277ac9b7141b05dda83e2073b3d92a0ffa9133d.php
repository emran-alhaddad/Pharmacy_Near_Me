
<?php $__env->startSection('admin_pages'); ?>
    <div class="wrapper bg-white">
        <div class="row  ">
            <div class="col-12 col-m-12 col-sm-12">
                <div class="card bg-white m-5">

                    <div class="card-header d-flex justify-content-between">
                        <a href="/_admin/add_Complaints"><i class="fas fa-plus"></i></a>
                        <h3>الشكاوى</h3>
                    </div>
                    <div class="card-content">
                        <?php if(session('error')): ?>
                            <div class="alert alert-danger" role="alert">
                                <?php echo e(session('error')); ?>

                            </div>
                        <?php endif; ?>
                        <?php if(session('status')): ?>
                            <div class="alert alert-success" role="alert">
                                <?php echo e(session('status')); ?>

                            </div>
                        <?php endif; ?>
                        <table class="table">
                            <thead>
                                <tr>
                                    <th> مقدم الشكوى</th>
                                    <th> على من الشكوى </th>
                                    <th>تاريخ تقديم الشكوى</th>
                                    <th>محتوى الشكوى</th>

                                    <th>العمليات</th>
                                </tr>
                            </thead>

                            <tbody>
                                <?php $__currentLoopData = $coms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $com): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($com->client->user->name); ?></td>
                                        <td><?php echo e($com->pharmacy->user->name); ?></td>
                                        <td> <?php echo e($com->created_at); ?></td>
                                        <td><?php echo e($com->message); ?></td>

                                        

                                        <td>
                                            <?php if($com->replay != null): ?>
                                                <button class="btn badge btn-danger text-white" data-bs-toggle="modal"
                                                    data-bs-target="#exampleModal<?php echo e($com->id); ?>">عرض الرد</button>
                                            <?php endif; ?>
                                            <?php if($com->order_reference): ?>
                                                <a href=<?php echo e(route('admin-complaint-orders', ['id' => $com->order_reference])); ?>>
                                                    <button class="btn badge btn-primary text-white">تفاصيل
                                                        الطلبية</button></a>
                                            <?php endif; ?>

                                            <div class="modal" id="exampleModal<?php echo e($com->id); ?>" tabindex="-1">
                                                <div class="modal-dialog">
                                                    <div class="modal-content">
                                                        <div class="modal-header">
                                                            <h5 class="modal-title">رد الشكوى </h5>
                                                        </div>
                                                        <div class="modal-body">
                                                            </p><?php echo e($com->replay); ?> </p>
                                                        </div>
                                                        <div class="modal-footer">
                                                            
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>

                                        </td>


                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>

                        </table>

                    </div>
                </div>
            </div>
        <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.masterAdmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Dell\Desktop\PROJECT صيدليتي\Pharmacy_Near_Me - Copy\resources\views/admin/Complaints/show_Complaints.blade.php ENDPATH**/ ?>