<!-- Show Image modal -->
<div class="modal fade" id="show_image" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" style="max-width:50vw; max-height:50vh">
        <div class="modal-content">
            <img src="" id="image_show" class="img-fluid" />
        </div>
    </div>
</div>
<?php /**PATH C:\Users\Dell\Desktop\PROJECT صيدليتي\Pharmacy_Near_Me - Copy\resources\views/shared/image-view.blade.php ENDPATH**/ ?>