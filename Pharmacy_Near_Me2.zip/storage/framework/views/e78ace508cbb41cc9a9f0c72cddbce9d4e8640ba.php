

    <?php $__env->startSection('content'); ?>

    <!--====== 404 PRODUCT PART START ======-->
	<section class="page-404-wrapper pt-5" style="direction: rtl;">
		<div class="container">
			<div class="row">
				<div class="col-xl-12 p-5">
					<div class="text-center content-404 p-5">
						<div class="image  p-5">
							<img src="<?php echo e(asset('Front/assets/images/404/404-img.svg')); ?>" alt="">
						</div>
						<h1>الصفحة ليست موجودة</h1>
					</div>
				</div>
			</div>
		</div>
	</section>
	<!--====== 404 PRODUCT PART ENDS ======-->

    <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.masterFront', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Dell\Desktop\PROJECT صيدليتي\Pharmacy_Near_Me - Copy\resources\views/errors/405.blade.php ENDPATH**/ ?>