<?php echo $__env->make('includes.FrontAdminNavbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php echo $__env->make('includes.FrontAdminSidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php echo $__env->yieldContent('admin_pages'); ?>

<?php echo $__env->make('shared.image-view', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</body>

<script src="<?php echo e(asset('admin/js/script2.js')); ?>"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"
integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>
<script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>

<?php if(session('error')): ?>
    <script>
        swal("عملية غير مكتملة", "<?php echo session('error'); ?>", "error")
    </script>
<?php endif; ?>
<?php if(session('status')): ?>
    <script>
        swal("أكتملت العملية", "<?php echo session('status'); ?>", "success")
    </script>
<?php endif; ?>

</html>

</html>
<?php /**PATH C:\Users\Dell\Desktop\PROJECT صيدليتي\Pharmacy_Near_Me\resources\views/layouts/masterAdmin.blade.php ENDPATH**/ ?>