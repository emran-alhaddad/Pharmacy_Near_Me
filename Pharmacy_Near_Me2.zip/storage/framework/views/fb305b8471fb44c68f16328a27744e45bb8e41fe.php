

<?php $__env->startSection('content'); ?>

    <div class="container-fluid radius " style=" margin-block-end: 50px;direction: rtl">

        <div class="radius" style="margin-top:105px">
            <div class=" d-flex justify-content-center">
                <div class="col-md-4 col-sm-12 shadow-lg p-5 bg-light">
                    <?php if(session('error')): ?>
                        <div class="alert alert-danger alert-dismissible d-flex align-items-center fade show" role="alert">
                            <svg class="bi flex-shrink-0 me-2" width="24" height="24" role="img" aria-label="Danger:">
                                <use xlink:href="#exclamation-triangle-fill" />
                            </svg>
                            <div>
                                <?php echo session('error'); ?>

                            </div>
                            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                        </div>
                    <?php endif; ?>
                    <div class="text-center">
                        <h3 class="heading">تسجيل<span>دخول</span></h3>
                    </div>
                    <form action="<?php echo e(route('login')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <div class="p-4">

                            <div class="input-group mb-3">
                                <span class="input-group-text rounded" style="background-color: var(--main-color)"><i
                                        class="bi bi-envelope-fill text-white"></i></span>
                                <input type="email" value="<?php echo e(old('email')); ?>" placeholder="الايميل" name="email"
                                    class="form-control rounded <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-danger <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback d-block">
                                        <?php echo e($message); ?>

                                    </div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="input-group mb-3 rounded">
                                <span class="input-group-text rounded" style="background-color: var(--main-color)"><i
                                        class="bi bi-key-fill text-white"></i></span>
                                <input type="password" placeholder="كلمة المرور" name="password"
                                    class="form-control rounded <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-danger <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback d-block">
                                        <?php echo e($message); ?>

                                    </div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <button class="btn-submit radius text-center p-2 col-12 mt-2 btn-hover" type="submit">
                                دخول
                            </button>
                            <p class="text-center mt-5">ليس لديك حساب؟

                                <span class="text-primary"> <a href="<?php echo e(route('register')); ?>">تسجيل حساب</a></span>
                            </p>
                            <p class="text-center text-primary"> <a href="<?php echo e(route('forget-password')); ?>">نسيت كلمة
                                    المرور؟</a></p>
                        </div>
                    </form>
                    <div class="container">
                        <div class="row">
                            <div class="col-xl-12 col-md-12">
                                <div class="footer-widget about">
                                    <ul class="social text-center d-flex justify-content-center">
                                        <p class="text-center ml-1">أو يمكنك الدخول عبر </p>
                                        <li class="m-1 btn-hover"><a href="<?php echo e(route('facebook-client')); ?>"><i
                                                    class="lni lni-facebook-filled btn-submit p-1 btn-hover"></i></a></li>
                                        <li class="m-1 btn-hover"><a href="<?php echo e(route('google-client')); ?>"><i
                                                    class="lni lni-google btn-submit p-1 btn-hover"></i></a></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.masterFront', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Dell\Desktop\PROJECT صيدليتي\Pharmacy_Near_Me - Copy\resources\views/auth/login.blade.php ENDPATH**/ ?>