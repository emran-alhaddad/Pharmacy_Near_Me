

<?php $__env->startSection('content'); ?>

    <!-- Content -->
    <div class="container-xxl flex-grow-1 container-p-y">
        <div class="container">
            <nav class="navbar navbar-light bg-light">
                <div class="container-fluid">
                    <a class="navbar-brand"> رصيدك الحالي هو <?php echo e($user->balance); ?> $</a>
                    <?php if($user->balance > 0): ?>
                        <button type="submit" class="btn btn-submit btn-hover  me-2">سحب رصيد من المحفظة <i
                                class="lni lni-search-alt"></i></button>
                    <?php endif; ?>
                    <form class="d-flex">
                        <input class="form-control me-2" type="search" placeholder="بحث" aria-label="Search">
                        <button class="btn btn-outline-success" type="submit">بحث</button>
                    </form>

            </nav>
            <!--table-->
            <div class="row  ">
                <div class="col-12 col-m-12 col-sm-12">
                    <div class="card bg-white m-5">

                        <div class="card-header d-flex justify-content-between">

                            <h5>العمليات في المحفظة</h5>
                        </div>
                        <div class="card-content">
                            <table class="table table-hover">
                                <thead>
                                    <tr>
                                        <th> رقم العملية </th>
                                        <th>نص العملية</th>
                                        <th></th>

                                    </tr>
                                </thead>

                                <tbody>
                                    <?php $__currentLoopData = $transactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transaction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($transaction['id']); ?></td>
                                            <td>
                                                <?php if($transaction['type'] == 'deposit'): ?>
                                                    أودع /
                                                    <?php echo e($transaction['sender']); ?>

                                                    <?php echo e($transaction['amount']); ?>$
                                                    إلى حسابك
                                                <?php elseif($transaction['type'] == 'withdraw'): ?>
                                                    لقد قمت بتحويل
                                                    <?php echo e($transaction['amount']); ?>$
                                                    إلى حساب
                                                    <?php echo e($transaction['sender']); ?>

                                                <?php endif; ?>

                                                بتاريخ
                                                <?php echo e($transaction['date']); ?>


                                            </td>
                                            <td>
                                                <a class=" btn btn-submit text-light btn-hover me-2" data-bs-toggle="collapse"
                                                    role="button" data-bs-target="#details<?php echo e($transaction['id']); ?>">
                                                    عرض التفاصيل
                                                </a>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td colspan="3">
                                                <div class="collapse" id="details<?php echo e($transaction['id']); ?>">
                                                    <div class="card card-body">
                                                        <?php echo $transaction['data']; ?>

                                                    </div>
                                                </div>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                                </tbody>

                            </table>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>




    <!-- / Content -->



<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.masterUser2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Dell\Desktop\PROJECT صيدليتي\Pharmacy_Near_Me\resources\views/user/bag.blade.php ENDPATH**/ ?>