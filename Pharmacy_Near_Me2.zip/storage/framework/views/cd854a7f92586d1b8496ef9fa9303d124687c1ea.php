<aside id="layout-menu" class="layout-menu menu-vertical menu bg-menu-theme shadow  my-3 mb-4 rounded-3">
<div class="row">
                    <?php $__errorArgs = ['avater'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="alert alert-danger" role="alert">
                            <?php echo e($message); ?>

                        </div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

    <div class="app-brand demo">
        <a href=" <?php echo e(route('index')); ?>" class="app-brand-link">
            <a class="navbar-brand" href="<?php echo e(route('index')); ?>">
                <img src="<?php echo e(asset('Front/assets/images/about/علاجي-01-3.svg')); ?>" id="logo" alt="Logo">
            </a>
        </a>

        <a href="javascript:void(0);" class="layout-menu-toggle menu-link text-large ms-auto d-block d-xl-none">
            <i class="bx bx-chevron-left bx-sm align-middle"></i>
        </a>
    </div>

    <div class="card-body text-center mt-2">
        <a href="<?php echo e(route('client-dashboard')); ?>">
            <img src="<?php echo e(asset('uploads/avaters/client/'.Auth::user()->avater)); ?>" alt="avatar"
                class="rounded-circle img-fluid" style="width: 150px;">
                <span style="margin-top: -50px;">
                    <div class="d-flex justify-content-center mb-2">
                    <i class="fas fa-pen"></i>
                    </div>
                </span>
            </a>
        
    </div>

    <div class="menu-inner-shadow"></div>
    <ul class="menu-inner py-1">
        <li class="menu-item">
        <a href="<?php echo e(route('index')); ?>" class="menu-link"><i class="bx bx-home-alt me-1"></i>
            <div data-i18n="Account">الرئيسية</div>
        </a>
        </li>
        <li class="menu-item">
        <a href="<?php echo e(route('chatify')); ?>" class="menu-link"><i class="bx bx-message-alt me-1"></i>
            <div data-i18n="Account">الرسائل</div>
        </a>
        </li>
        <li class="menu-item">
        <a href="<?php echo e(route('myorder')); ?>" class="menu-link"><i class="bx bx-shopping-bag me-1"></i>
            <div data-i18n="Account">طلبياتي </div>
        </a>
        </li>
        <li class="menu-item">

        <li class="menu-item">
        <a href="<?php echo e(route('problems')); ?>" class="menu-link"><i class="bx bx-chat me-1"></i>
            <div data-i18n="Account">الشكاوي</div>
        </a>
        </li>
        <li class="menu-item">
        <a href="<?php echo e(route('client-dashboard')); ?>" class="menu-link"><i class="bx bx-user me-1"></i>
            <div data-i18n="Account">البروفايل</div>
        </a>
        </li>
        <li class="menu-item">
        <a href="<?php echo e(route('bag-user')); ?>" class="menu-link"><i class="bx bx-notification  me-1"></i>
            <div data-i18n="Account">محفظتي</div>
        </a>
        </li>
        <li class="menu-item">
        <a href="<?php echo e(route('logout')); ?>" class="menu-link"><i class="bx bx-power-off me-1"></i>
            <div data-i18n="Account">تسجيل خروج</div>
        </a>
        </li>


    </ul>
</aside>
<?php /**PATH C:\Users\Dell\Desktop\PROJECT صيدليتي\Pharmacy_Near_Me - Copy\resources\views/includes/UserAside.blade.php ENDPATH**/ ?>