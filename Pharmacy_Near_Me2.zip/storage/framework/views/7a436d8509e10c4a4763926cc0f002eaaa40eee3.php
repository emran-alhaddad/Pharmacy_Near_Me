

<?php $__env->startSection('phar_profile_content'); ?>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.masterPharmacy', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Dell\Desktop\PROJECT صيدليتي\Pharmacy_Near_Me - Copy\resources\views/pharmacy/index.blade.php ENDPATH**/ ?>